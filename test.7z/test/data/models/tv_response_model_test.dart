import 'dart:convert';

import 'package:ditonton/data/models/movie_model.dart';
import 'package:ditonton/data/models/tv_model.dart';
import 'package:ditonton/data/models/tv_response.dart';
import 'package:flutter_test/flutter_test.dart';

import '../../json_reader.dart';

void main() { 
  final tTvModel = TvModel(
      backdropPath: "/99vBORZixICa32Pwdwj0lWcr8K.jpg",
      firstAirDate: "2021-09-03",
      genreIds: [10764],
      id: 130392,
      name: "The D'Amelio Show",
      originCountry: ["US"],
      originalLanguage: "en",
      originalName: "The D'Amelio Show",
      overview:
          "From relative obscurity and a seemingly normal life, to overnight success and thrust into the Hollywood limelight overnight, the D’Amelios are faced with new challenges and opportunities they could not have imagined.",
      popularity: 25.383,
      posterPath: "/phv2Jc4H8cvRzvTKb9X1uKMboTu.jpg",
      voteAverage: 9,
      voteCount: 3134);
  final tTvResponseModel = TvResponse(tvList: <TvModel>[tTvModel]);
  group('fromJson', () {
    test('should return a valid model from JSON', () async {
      // arrange
      final Map<String, dynamic> jsonMap =
          json.decode(readJson('dummy_data/tv_now_playing.json'));
      // act
      final result = TvResponse.fromJson(jsonMap);
  print(result);
      // assert
      expect(result, tTvResponseModel);
    });
  });

  group('toJson', () {
    test('should return a JSON map containing proper data', () async {
      // arrange

      // act
      final result = tTvResponseModel.toJson();
      // assert
      final expectedJsonMap = {
        "results": [
          {
            "backdrop_path": "/99vBORZixICa32Pwdwj0lWcr8K.jpg",
            "first_air_date": "2021-09-03",
            "genre_ids": [10764],
            "id": 130392,
            "name": "The D'Amelio Show",
            "origin_country": ["US"],
            "original_language": "en",
            "original_name": "The D'Amelio Show",
            "overview":
                "From relative obscurity and a seemingly normal life, to overnight success and thrust into the Hollywood limelight overnight, the D’Amelios are faced with new challenges and opportunities they could not have imagined.",
            "popularity": 25.383,
            "poster_path": "/phv2Jc4H8cvRzvTKb9X1uKMboTu.jpg",
            "vote_average": 9,
            "vote_count": 3134
          }
        ],
      };
      expect(result, expectedJsonMap);
    });
  });
}
