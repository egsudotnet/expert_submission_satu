// import 'dart:io';

// import 'package:dartz/dartz.dart';
// import 'package:ditonton/data/models/genre_model.dart';
// import 'package:ditonton/data/models/tv_detail_model.dart';
// import 'package:ditonton/data/models/tv_model.dart';
// import 'package:ditonton/data/repositories/tv_repository_impl.dart';
// import 'package:ditonton/common/exception.dart';
// import 'package:ditonton/common/failure.dart';
// import 'package:ditonton/domain/entities/tv.dart';
// import 'package:flutter_test/flutter_test.dart';
// import 'package:mockito/mockito.dart';

// import '../../dummy_data/tv_dummy_objects.dart';
// import '../../helpers/test_helper.mocks.dart';

// void main() {
//   late TvRepositoryImpl repository;
//   late MockTvRemoteDataSource mockRemoteDataSource;
//   late MockTvLocalDataSource mockLocalDataSource;

//   setUp(() {
//     mockRemoteDataSource = MockTvRemoteDataSource();
//     mockLocalDataSource = MockTvLocalDataSource();
//     repository = TvRepositoryImpl(
//       remoteDataSource: mockRemoteDataSource,
//       localDataSource: mockLocalDataSource,
//     );
//   });

//   final tTvModel = TvModel(
//     backdropPath: "/99vBORZixICa32Pwdwj0lWcr8K.jpg",
//     firstAirDate:"2021-09-03",
//     genreIds: [10764],
//     id: 130392,
//     name: "The D'Amelio Show",
//     originCountry: ["US"],
//     originalLanguage: "en",
//     originalName: "The D'Amelio Show",
//     overview:
//         "From relative obscurity and a seemingly normal life, to overnight success and thrust into the Hollywood limelight overnight, the D’Amelios are faced with new challenges and opportunities they could not have imagined.",
//     popularity: 25.383,
//     posterPath: "/phv2Jc4H8cvRzvTKb9X1uKMboTu.jpg",
//     voteAverage: 9,
//     voteCount: 3134
//   );

//   final tTv = Tv(
//     backdropPath: "/99vBORZixICa32Pwdwj0lWcr8K.jpg",
//     firstAirDate: "2021-09-03",
//     genreIds: [10764],
//     id: 130392,
//     name: "The D'Amelio Show",
//     originCountry: ["US"],
//     originalLanguage: "en",
//     originalName: "The D'Amelio Show",
//     overview:
//         "From relative obscurity and a seemingly normal life, to overnight success and thrust into the Hollywood limelight overnight, the D’Amelios are faced with new challenges and opportunities they could not have imagined.",
//     popularity: 25.383,
//     posterPath: "/phv2Jc4H8cvRzvTKb9X1uKMboTu.jpg",
//     voteAverage: 9,
//     voteCount: 3134
//   );

//   final tTvModelList = <TvModel>[tTvModel];
//   final tTvList = <Tv>[tTv];

//   group('Now Playing Tvs', () {
//     test(
//         'should return remote data when the call to remote data source is successful',
//         () async {
//       // arrange
//       when(mockRemoteDataSource.getNowPlayingTvs())
//           .thenAnswer((_) async => tTvModelList);
//       // act
//       final result = await repository.getNowPlayingTvs();
//       // assert
//       verify(mockRemoteDataSource.getNowPlayingTvs());
//       /* workaround to test List in Right. Issue: https://github.com/spebbe/dartz/issues/80 */
//       final resultList = result.getOrElse(() => []);
//       expect(resultList, tTvList);
//     });

//     test(
//         'should return server failure when the call to remote data source is unsuccessful',
//         () async {
//       // arrange
//       when(mockRemoteDataSource.getNowPlayingTvs())
//           .thenThrow(ServerException());
//       // act
//       final result = await repository.getNowPlayingTvs();
//       // assert
//       verify(mockRemoteDataSource.getNowPlayingTvs());
//       expect(result, equals(Left(ServerFailure(''))));
//     });

//     test(
//         'should return connection failure when the device is not connected to internet',
//         () async {
//       // arrange
//       when(mockRemoteDataSource.getNowPlayingTvs())
//           .thenThrow(SocketException('Failed to connect to the network'));
//       // act
//       final result = await repository.getNowPlayingTvs();
//       // assert
//       verify(mockRemoteDataSource.getNowPlayingTvs());
//       expect(result,
//           equals(Left(ConnectionFailure('Failed to connect to the network'))));
//     });
//   });

//   group('Popular Tvs', () {
//     test('should return tv list when call to data source is success',
//         () async {
//       // arrange
//       when(mockRemoteDataSource.getPopularTvs())
//           .thenAnswer((_) async => tTvModelList);
//       // act
//       final result = await repository.getPopularTvs();
//       // assert
//       /* workaround to test List in Right. Issue: https://github.com/spebbe/dartz/issues/80 */
//       final resultList = result.getOrElse(() => []);
//       expect(resultList, tTvList);
//     });

//     test(
//         'should return server failure when call to data source is unsuccessful',
//         () async {
//       // arrange
//       when(mockRemoteDataSource.getPopularTvs())
//           .thenThrow(ServerException());
//       // act
//       final result = await repository.getPopularTvs();
//       // assert
//       expect(result, Left(ServerFailure('')));
//     });

//     test(
//         'should return connection failure when device is not connected to the internet',
//         () async {
//       // arrange
//       when(mockRemoteDataSource.getPopularTvs())
//           .thenThrow(SocketException('Failed to connect to the network'));
//       // act
//       final result = await repository.getPopularTvs();
//       // assert
//       expect(
//           result, Left(ConnectionFailure('Failed to connect to the network')));
//     });
//   });

//   group('Top Rated Tvs', () {
//     test('should return tv list when call to data source is successful',
//         () async {
//       // arrange
//       when(mockRemoteDataSource.getTopRatedTvs())
//           .thenAnswer((_) async => tTvModelList);
//       // act
//       final result = await repository.getTopRatedTvs();
//       // assert
//       /* workaround to test List in Right. Issue: https://github.com/spebbe/dartz/issues/80 */
//       final resultList = result.getOrElse(() => []);
//       expect(resultList, tTvList);
//     });

//     test('should return ServerFailure when call to data source is unsuccessful',
//         () async {
//       // arrange
//       when(mockRemoteDataSource.getTopRatedTvs())
//           .thenThrow(ServerException());
//       // act
//       final result = await repository.getTopRatedTvs();
//       // assert
//       expect(result, Left(ServerFailure('')));
//     });

//     test(
//         'should return ConnectionFailure when device is not connected to the internet',
//         () async {
//       // arrange
//       when(mockRemoteDataSource.getTopRatedTvs())
//           .thenThrow(SocketException('Failed to connect to the network'));
//       // act
//       final result = await repository.getTopRatedTvs();
//       // assert
//       expect(
//           result, Left(ConnectionFailure('Failed to connect to the network')));
//     });
//   });

//   group('Get Tv Detail', () {
//     final tId = 1;
//     final tTvResponse = TvDetailResponse(
//       adult: false,
//       backdropPath: "/99vBORZixICa32Pwdwj0lWcr8K.jpg",
//       createdBy: [],
//       episodeRunTime: [],
//       firstAirDate: "2021-09-03",
//       genres: [GenreModel(id: 1, name: 'Action')],
//       homepage:
//           "https://www.hulu.com/series/the-damelio-show-ad993806-7961-4eb3-9f92-e7b9a349ae22",
//       id: 130392,
//       inProduction: true,
//       languages: ["en"],
//       lastAirDate: "2022-10-26",
//       lastEpisodeToAir: LastEpisodeToAir.fromJson({
//         "air_date": "2022-10-26",
//         "episode_number": 10,
//         "id": 4025919,
//         "name": "This Season Has Been a Rollercoaster",
//         "overview":
//             "As Charli and her new guy friend face harsh rumors, she makes some exciting moves as she turns 18-both in her love life and with her music; Dixie prepares for her album launch and live performance, but anxiety threatens two years of hard work; Charli debuts the music video for her debut single \"if you ask me to\"",
//         "production_code": "",
//         "runtime": 48,
//         "season_number": 2,
//         "show_id": 130392,
//         "still_path": "/vZW7gXM3jwTI7LG8BRxuLmh1bKZ.jpg",
//         "vote_average": 1.0,
//         "vote_count": 1
//         }), 
//       name: "The D'Amelio Show",
//       nextEpisodeToAir: null,
//       networks: List<Network>.from([
//           {
//           "id": 453,
//           "name": "Hulu",
//           "logo_path": "/pqUTCleNUiTLAVlelGxUgWn1ELh.png",
//           "origin_country": "US"
//           }
//         ].map((x) => Network.fromJson(x))), 
//       numberOfEpisodes: 18,
//       numberOfSeasons: 2,
//       originCountry: ["US"],
//       originalLanguage: "en",
//       originalName: "The D'Amelio Show",
//       overview:
//           "From relative obscurity and a seemingly normal life, to overnight success and thrust into the Hollywood limelight overnight, the D’Amelios are faced with new challenges and opportunities they could not have imagined.",
//       popularity: 25.383,
//       posterPath: "/phv2Jc4H8cvRzvTKb9X1uKMboTu.jpg",
//       productionCompanies: List<Network>.from([
//             {
//             "id": 83966,
//             "logo_path": "/q2BuooxLm16EvWcUY4CMJo3PSNo.png",
//             "name": "The Intellectual Property Corporation",
//             "origin_country": "US"
//             },
//             {
//             "id": 165537,
//             "logo_path": null,
//             "name": "The D'Amelios",
//             "origin_country": "US"
//             }
//           ].map((x) => Network.fromJson(x))), 
//       productionCountries: List<ProductionCountry>.from([
//           {
//           "iso_3166_1": "US",
//           "name": "United States of America"
//           }
//           ].map((x) => ProductionCountry.fromJson(x))), 
          
//       seasons: List<Season>.from([
//           {
//           "air_date": "2021-09-03",
//           "episode_count": 8,
//           "id": 204453,
//           "name": "Season 1",
//           "overview": "",
//           "poster_path": "/z0iCS5Znx7TeRwlYSd4c01Z0lFx.jpg",
//           "season_number": 1
//           },
//           {
//           "air_date": "2022-09-28",
//           "episode_count": 10,
//           "id": 303094,
//           "name": "Season 2",
//           "overview": "As personal and professional relationships overlap, the D'Amelio family faces new challenges at every turn, from public scandals to maintaining mental health, as they share the truth behind their online lives.",
//           "poster_path": "/phv2Jc4H8cvRzvTKb9X1uKMboTu.jpg",
//           "season_number": 2
//           }
//           ].map((x) => Season.fromJson(x))), 
//       spokenLanguages: List<SpokenLanguage>.from([
//           {
//           "english_name": "English",
//           "iso_639_1": "en",
//           "name": "English"
//           }
//           ].map((x) => SpokenLanguage.fromJson(x))), 
//       status: "Returning Series",
//       tagline: "Fame is one thing, family is everything.",
//       type: "Reality",
//       voteAverage: 9.0,
//       voteCount: 3134
//     );

//     test(
//         'should return Tv data when the call to remote data source is successful',
//         () async {
//       // arrange
//       when(mockRemoteDataSource.getTvDetail(tId))
//           .thenAnswer((_) async => tTvResponse);
//       // act
//       final result = await repository.getTvDetail(tId);
//       // assert
//       verify(mockRemoteDataSource.getTvDetail(tId));
//       expect(result, equals(Right(testTvDetail)));
//     });

//     test(
//         'should return Server Failure when the call to remote data source is unsuccessful',
//         () async {
//       // arrange
//       when(mockRemoteDataSource.getTvDetail(tId))
//           .thenThrow(ServerException());
//       // act
//       final result = await repository.getTvDetail(tId);
//       // assert
//       verify(mockRemoteDataSource.getTvDetail(tId));
//       expect(result, equals(Left(ServerFailure(''))));
//     });

//     test(
//         'should return connection failure when the device is not connected to internet',
//         () async {
//       // arrange
//       when(mockRemoteDataSource.getTvDetail(tId))
//           .thenThrow(SocketException('Failed to connect to the network'));
//       // act
//       final result = await repository.getTvDetail(tId);
//       // assert
//       verify(mockRemoteDataSource.getTvDetail(tId));
//       expect(result,
//           equals(Left(ConnectionFailure('Failed to connect to the network'))));
//     });
//   });

//   group('Get Tv Recommendations', () {
//     final tTvList = <TvModel>[];
//     final tId = 1;

//     test('should return data (tv list) when the call is successful',
//         () async {
//       // arrange
//       when(mockRemoteDataSource.getTvRecommendations(tId))
//           .thenAnswer((_) async => tTvList);
//       // act
//       final result = await repository.getTvRecommendations(tId);
//       // assert
//       verify(mockRemoteDataSource.getTvRecommendations(tId));
//       /* workaround to test List in Right. Issue: https://github.com/spebbe/dartz/issues/80 */
//       final resultList = result.getOrElse(() => []);
//       expect(resultList, equals(tTvList));
//     });

//     test(
//         'should return server failure when call to remote data source is unsuccessful',
//         () async {
//       // arrange
//       when(mockRemoteDataSource.getTvRecommendations(tId))
//           .thenThrow(ServerException());
//       // act
//       final result = await repository.getTvRecommendations(tId);
//       // assertbuild runner
//       verify(mockRemoteDataSource.getTvRecommendations(tId));
//       expect(result, equals(Left(ServerFailure(''))));
//     });

//     test(
//         'should return connection failure when the device is not connected to the internet',
//         () async {
//       // arrange
//       when(mockRemoteDataSource.getTvRecommendations(tId))
//           .thenThrow(SocketException('Failed to connect to the network'));
//       // act
//       final result = await repository.getTvRecommendations(tId);
//       // assert
//       verify(mockRemoteDataSource.getTvRecommendations(tId));
//       expect(result,
//           equals(Left(ConnectionFailure('Failed to connect to the network'))));
//     });
//   });

//   group('Seach Tvs', () {
//     final tQuery = 'spiderman';

//     test('should return tv list when call to data source is successful',
//         () async {
//       // arrange
//       when(mockRemoteDataSource.searchTvs(tQuery))
//           .thenAnswer((_) async => tTvModelList);
//       // act
//       final result = await repository.searchTvs(tQuery);
//       // assert
//       /* workaround to test List in Right. Issue: https://github.com/spebbe/dartz/issues/80 */
//       final resultList = result.getOrElse(() => []);
//       expect(resultList, tTvList);
//     });

//     test('should return ServerFailure when call to data source is unsuccessful',
//         () async {
//       // arrange
//       when(mockRemoteDataSource.searchTvs(tQuery))
//           .thenThrow(ServerException());
//       // act
//       final result = await repository.searchTvs(tQuery);
//       // assert
//       expect(result, Left(ServerFailure('')));
//     });

//     test(
//         'should return ConnectionFailure when device is not connected to the internet',
//         () async {
//       // arrange
//       when(mockRemoteDataSource.searchTvs(tQuery))
//           .thenThrow(SocketException('Failed to connect to the network'));
//       // act
//       final result = await repository.searchTvs(tQuery);
//       // assert
//       expect(
//           result, Left(ConnectionFailure('Failed to connect to the network')));
//     });
//   });

//   group('save watchlist', () {
//     test('should return success message when saving successful', () async {
//       // arrange
//       when(mockLocalDataSource.insertWatchlistTv(testTvTable))
//           .thenAnswer((_) async => 'Added to Watchlist');
//       // act
//       final result = await repository.saveWatchlistTv(testTvDetail);
//       // assert
//       expect(result, Right('Added to Watchlist'));
//     });

//     test('should return DatabaseFailure when saving unsuccessful', () async {
//       // arrange
//       when(mockLocalDataSource.insertWatchlistTv(testTvTable))
//           .thenThrow(DatabaseException('Failed to add watchlist'));
//       // act
//       final result = await repository.saveWatchlistTv(testTvDetail);
//       // assert
//       expect(result, Left(DatabaseFailure('Failed to add watchlist')));
//     });
//   });

//   group('remove watchlist', () {
//     test('should return success message when remove successful', () async {
//       // arrange
//       when(mockLocalDataSource.removeWatchlistTv(testTvTable))
//           .thenAnswer((_) async => 'Removed from watchlist');
//       // act
//       final result = await repository.removeWatchlistTv(testTvDetail);
//       // assert
//       expect(result, Right('Removed from watchlist'));
//     });

//     test('should return DatabaseFailure when remove unsuccessful', () async {
//       // arrange
//       when(mockLocalDataSource.removeWatchlistTv(testTvTable))
//           .thenThrow(DatabaseException('Failed to remove watchlist'));
//       // act
//       final result = await repository.removeWatchlistTv(testTvDetail);
//       // assert
//       expect(result, Left(DatabaseFailure('Failed to remove watchlist')));
//     });
//   });

//   group('get watchlist status', () {
//     test('should return watch status whether data is found', () async {
//       // arrange
//       final tId = 1;
//       when(mockLocalDataSource.getTvById(tId)).thenAnswer((_) async => null);
//       // act
//       final result = await repository.isAddedToWatchlist(tId);
//       // assert
//       expect(result, false);
//     });
//   });

//   group('get watchlist tvs', () {
//     test('should return list of Tvs', () async {
//       // arrange
//       when(mockLocalDataSource.getWatchlistTvs())
//           .thenAnswer((_) async => [testTvTable]);
//       // act
//       final result = await repository.getWatchlistTvs();
//       // assert
//       final resultList = result.getOrElse(() => []);
//       expect(resultList, [testWatchlistTv]);
//     });
//   });
// }
